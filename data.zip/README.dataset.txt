# IngrDetection > 2024-06-27 4:35pm
https://universe.roboflow.com/uitm-ahefu/ingrdetection

Provided by a Roboflow user
License: CC BY 4.0

